import React, {Component}  from 'react';
import  ReactDOM  from 'react-dom';
import Main from './Components/Main';
import './Styles/stylesheet.css';


ReactDOM.render(<Main/>,document.getElementById('root'));
